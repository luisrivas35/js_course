const todosLosLibros = document.querySelector('#todosLosLibros')

const URL_DOMAIN = "http://localhost:3000"

const obtenerLibros = async () => {
    try {
        const { data: libros } = await axios.get(URL_DOMAIN + '/libros')
        todosLosLibros.innerHTML = ''
        libros.forEach(libro => {
            todosLosLibros.innerHTML += `
            <li class="list-group-item">
                <div class="mb-2">
                    Nombre: ${libro.nombre} 
                    - autor: ${libro.autor} 
                    - precio: ${libro.precio}
                </div>
                <div>
                    <button 
                        onclick="eliminarLibro('${libro.id}')" 
                        class="btn btn-danger btn-sm">Eliminar</button>
                    <button 
                        onclick="editarLibro('${libro.id}')" 
                        class="btn btn-warning btn-sm">Editar</button>
                </div>
            </li>
            `
        })
    } catch (error) {
        console.log(error)
        alert('Falló la petición de libros...')
    }
}

obtenerLibros()

const eliminarLibro = async (id) => {
    console.log(typeof id)
    console.log('me estás eliminando...', id)
}

const editarLibro = async (id) => {
    console.log(typeof id)
    console.log('me estás editando...', id)
}

